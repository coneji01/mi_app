import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiClient {
  final String baseUrl;
  String? _token;
  ApiClient(this.baseUrl);

  Future<void> _loadToken() async {
    final sp = await SharedPreferences.getInstance();
    _token = sp.getString('token');
  }

  Future<void> _saveToken(String t) async {
    _token = t;
    final sp = await SharedPreferences.getInstance();
    await sp.setString('token', t);
  }

  Map<String, String> _headers({bool auth = false}) {
    final h = {'Content-Type': 'application/json'};
    if (auth && _token != null) h['Authorization'] = 'Bearer $_token';
    return h;
  }

  // ------------ AUTH ------------
  Future<void> login(String email, String password) async {
    final uri = Uri.parse('$baseUrl/auth/login');
    final res = await http.post(
      uri,
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: {'username': email, 'password': password},
    );
    if (res.statusCode != 200) {
      throw Exception('Login falló: ${res.statusCode} ${res.body}');
    }
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final t = data['access_token'] as String?;
    if (t == null) throw Exception('Token no recibido');
    await _saveToken(t);
  }

  // ------------ CLIENTES ------------
  Future<List<Map<String, dynamic>>> listClientes({String? search}) async {
    await _loadToken();
    final q = (search == null || search.isEmpty) ? '' : '?search=${Uri.encodeQueryComponent(search)}';
    final uri = Uri.parse('$baseUrl/clientes$q');
    final res = await http.get(uri, headers: _headers(auth: true));
    if (res.statusCode != 200) throw Exception('Listar clientes: ${res.statusCode} ${res.body}');
    return (jsonDecode(res.body) as List).cast<Map<String, dynamic>>();
  }

  Future<Map<String, dynamic>> createCliente(Map<String, dynamic> body) async {
    await _loadToken();
    final res = await http.post(Uri.parse('$baseUrl/clientes'),
        headers: _headers(auth: true), body: jsonEncode(body));
    if (res.statusCode != 200 && res.statusCode != 201) {
      throw Exception('Crear cliente: ${res.statusCode} ${res.body}');
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> updateCliente(int id, Map<String, dynamic> body) async {
    await _loadToken();
    final res = await http.put(Uri.parse('$baseUrl/clientes/$id'),
        headers: _headers(auth: true), body: jsonEncode(body));
    if (res.statusCode != 200) {
      throw Exception('Actualizar cliente: ${res.statusCode} ${res.body}');
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<void> deleteCliente(int id) async {
    await _loadToken();
    final res = await http.delete(Uri.parse('$baseUrl/clientes/$id'), headers: _headers(auth: true));
    if (res.statusCode != 200) throw Exception('Eliminar cliente: ${res.statusCode} ${res.body}');
  }

  // ------------ PRÉSTAMOS ------------
  Future<List<Map<String, dynamic>>> listPrestamos() async {
    await _loadToken();
    final res = await http.get(Uri.parse('$baseUrl/prestamos'), headers: _headers(auth: true));
    if (res.statusCode != 200) throw Exception('Listar préstamos: ${res.statusCode} ${res.body}');
    return (jsonDecode(res.body) as List).cast<Map<String, dynamic>>();
  }

  Future<Map<String, dynamic>> createPrestamo(Map<String, dynamic> body) async {
    await _loadToken();
    final res = await http.post(Uri.parse('$baseUrl/prestamos'),
        headers: _headers(auth: true), body: jsonEncode(body));
    if (res.statusCode != 200 && res.statusCode != 201) {
      throw Exception('Crear préstamo: ${res.statusCode} ${res.body}');
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> updatePrestamo(int id, Map<String, dynamic> body) async {
    await _loadToken();
    final res = await http.put(Uri.parse('$baseUrl/prestamos/$id'),
        headers: _headers(auth: true), body: jsonEncode(body));
    if (res.statusCode != 200) throw Exception('Actualizar préstamo: ${res.statusCode} ${res.body}');
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<void> deletePrestamo(int id) async {
    await _loadToken();
    final res = await http.delete(Uri.parse('$baseUrl/prestamos/$id'), headers: _headers(auth: true));
    if (res.statusCode != 200) throw Exception('Eliminar préstamo: ${res.statusCode} ${res.body}');
  }

  // ------------ PAGOS ------------
  Future<List<Map<String, dynamic>>> listPagosPorPrestamo(int prestamoId) async {
    await _loadToken();
    final res = await http.get(Uri.parse('$baseUrl/prestamos/$prestamoId/pagos'),
        headers: _headers(auth: true));
    if (res.statusCode != 200) throw Exception('Listar pagos: ${res.statusCode} ${res.body}');
    return (jsonDecode(res.body) as List).cast<Map<String, dynamic>>();
  }

  Future<Map<String, dynamic>> createPago(Map<String, dynamic> body) async {
    await _loadToken();
    final res = await http.post(Uri.parse('$baseUrl/pagos'),
        headers: _headers(auth: true), body: jsonEncode(body));
    if (res.statusCode != 200 && res.statusCode != 201) {
      throw Exception('Crear pago: ${res.statusCode} ${res.body}');
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<void> deletePago(int id) async {
    await _loadToken();
    final res = await http.delete(Uri.parse('$baseUrl/pagos/$id'), headers: _headers(auth: true));
    if (res.statusCode != 200) throw Exception('Eliminar pago: ${res.statusCode} ${res.body}');
  }
}
