enum DataMode { local, backend }
const kDataMode = DataMode.backend;   // debe estar así
