INSERT INTO pagos (fecha, monto, tipo, forma, caja, comentario, cliente) VALUES
(datetime('now','-270 day'), 1200, 'interes', 'Efectivo', 'Ninguna', 'Pago prueba 1', 'Pedro Rodriguez'),
(datetime('now','-260 day'), 3000, 'capital', 'Efectivo', 'Ninguna', 'Pago prueba 2', 'Eduvigen Goris'),
(datetime('now','-30 day'),  1500, 'interes', 'Transferencia', 'Principal', 'Pago prueba 3', 'Cossette Vasquez'),
(datetime('now','-5 day'),   3720, 'capital', 'Efectivo', 'Ninguna', 'Pago prueba 4', 'Robison Paez');

