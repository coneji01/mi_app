package com.example.mi_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
