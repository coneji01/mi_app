// The share_plus_platform_interface defaults to MethodChannelShare
// as its instance, which is all the macOS implementation needs. This file
// is here to silence warnings when publishing to pub.
