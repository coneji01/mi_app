// Panel eliminado: ahora se usa el Drawer único del HomeShell.
import 'package:flutter/widgets.dart';
class PanelPrincipalScreen extends StatelessWidget { const PanelPrincipalScreen({super.key});
@override Widget build(BuildContext context) => const SizedBox.shrink(); }
