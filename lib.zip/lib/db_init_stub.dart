// Fallback (no hace nada)
Future<void> initDbFactory() async {}
